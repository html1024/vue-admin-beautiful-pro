/*!
 * vue-admin-better
 * GitHub: https://github.com/zxwk1998/vue-admin-better
 * Gitee: https://gitee.com/chu1204505056/vue-admin-better
 *
 * 版权所有 (c) 2025 vue-admin-better
 * 本项目使用 MIT 许可证
 * 构建时间: 2026-2-6 02:44:29
 */
"use strict";
(self["webpackChunkvue_admin_better"] = self["webpackChunkvue_admin_better"] || []).push([["9713"], {
75430: (function (module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
/* import */ var _node_modules_pnpm_css_loader_7_1_3_rspack_core_1_7_5_webpack_5_105_0_node_modules_css_loader_dist_runtime_noSourceMaps_js__rspack_import_0 = __webpack_require__(97142);
/* import */ var _node_modules_pnpm_css_loader_7_1_3_rspack_core_1_7_5_webpack_5_105_0_node_modules_css_loader_dist_runtime_noSourceMaps_js__rspack_import_0_default = /*#__PURE__*/__webpack_require__.n(_node_modules_pnpm_css_loader_7_1_3_rspack_core_1_7_5_webpack_5_105_0_node_modules_css_loader_dist_runtime_noSourceMaps_js__rspack_import_0);
/* import */ var _node_modules_pnpm_css_loader_7_1_3_rspack_core_1_7_5_webpack_5_105_0_node_modules_css_loader_dist_runtime_api_js__rspack_import_1 = __webpack_require__(15751);
/* import */ var _node_modules_pnpm_css_loader_7_1_3_rspack_core_1_7_5_webpack_5_105_0_node_modules_css_loader_dist_runtime_api_js__rspack_import_1_default = /*#__PURE__*/__webpack_require__.n(_node_modules_pnpm_css_loader_7_1_3_rspack_core_1_7_5_webpack_5_105_0_node_modules_css_loader_dist_runtime_api_js__rspack_import_1);
// Imports


var ___CSS_LOADER_EXPORT___ = _node_modules_pnpm_css_loader_7_1_3_rspack_core_1_7_5_webpack_5_105_0_node_modules_css_loader_dist_runtime_api_js__rspack_import_1_default()((_node_modules_pnpm_css_loader_7_1_3_rspack_core_1_7_5_webpack_5_105_0_node_modules_css_loader_dist_runtime_noSourceMaps_js__rspack_import_0_default()));
// Module
___CSS_LOADER_EXPORT___.push([module.id, ".page-header{background:linear-gradient(135deg, #4d8af0 0%, #1a56db 100%);border-radius:12px;padding:30px;margin-bottom:24px;color:#fff;box-shadow:0 8px 32px rgba(102,126,234,.3)}.page-header .header-content{display:flex;justify-content:space-between;align-items:center}.page-header .header-content .header-left .page-title{font-size:2rem;font-weight:700;margin:0 0 8px 0;display:flex;align-items:center;gap:12px}.page-header .header-content .header-left .page-title .vab-icon{font-size:1.8rem}.page-header .header-content .header-left .page-description{font-size:1rem;opacity:.9;margin:0}.page-header .header-content .header-right{display:flex;align-items:center;gap:8px;font-size:1.1rem;font-weight:600}.page-header .header-content .header-right .vab-icon{font-size:1.3rem}", ""]);
// Exports
/* export default */ __webpack_exports__["default"] = (___CSS_LOADER_EXPORT___);


}),
4163: (function (module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
/* import */ var _node_modules_pnpm_css_loader_7_1_3_rspack_core_1_7_5_webpack_5_105_0_node_modules_css_loader_dist_runtime_noSourceMaps_js__rspack_import_0 = __webpack_require__(97142);
/* import */ var _node_modules_pnpm_css_loader_7_1_3_rspack_core_1_7_5_webpack_5_105_0_node_modules_css_loader_dist_runtime_noSourceMaps_js__rspack_import_0_default = /*#__PURE__*/__webpack_require__.n(_node_modules_pnpm_css_loader_7_1_3_rspack_core_1_7_5_webpack_5_105_0_node_modules_css_loader_dist_runtime_noSourceMaps_js__rspack_import_0);
/* import */ var _node_modules_pnpm_css_loader_7_1_3_rspack_core_1_7_5_webpack_5_105_0_node_modules_css_loader_dist_runtime_api_js__rspack_import_1 = __webpack_require__(15751);
/* import */ var _node_modules_pnpm_css_loader_7_1_3_rspack_core_1_7_5_webpack_5_105_0_node_modules_css_loader_dist_runtime_api_js__rspack_import_1_default = /*#__PURE__*/__webpack_require__.n(_node_modules_pnpm_css_loader_7_1_3_rspack_core_1_7_5_webpack_5_105_0_node_modules_css_loader_dist_runtime_api_js__rspack_import_1);
// Imports


var ___CSS_LOADER_EXPORT___ = _node_modules_pnpm_css_loader_7_1_3_rspack_core_1_7_5_webpack_5_105_0_node_modules_css_loader_dist_runtime_api_js__rspack_import_1_default()((_node_modules_pnpm_css_loader_7_1_3_rspack_core_1_7_5_webpack_5_105_0_node_modules_css_loader_dist_runtime_noSourceMaps_js__rspack_import_0_default()));
// Module
___CSS_LOADER_EXPORT___.push([module.id, ".tab-container[data-v-01f7f660]{padding:15px;background:#fff}.tab-container .tab-content[data-v-01f7f660]{min-height:400px}.tab-container .tab-content .tab-demo[data-v-01f7f660]{margin-bottom:30px}.tab-container .tab-content .tab-demo h3[data-v-01f7f660]{margin:20px 0;color:#333}.tab-container .tab-content .tab-demo .tab-pane-content[data-v-01f7f660]{padding:20px 0;color:#606266}.tab-container .tab-content .tab-demo .tab-pane-content .card-content[data-v-01f7f660]{text-align:center}.tab-container .tab-content .tab-demo .tab-pane-content .card-content .card-number[data-v-01f7f660]{font-size:24px;font-weight:bold;color:#409eff;margin:10px 0}.tab-container .tab-content .tab-demo .tab-pane-content .card-content .card-description[data-v-01f7f660]{color:#999}", ""]);
// Exports
/* export default */ __webpack_exports__["default"] = (___CSS_LOADER_EXPORT___);


}),
34685: (function (__unused_rspack_module, __webpack_exports__, __webpack_require__) {
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": function() { return /* binding */ VabPageHeader; }
});

;// CONCATENATED MODULE: ./node_modules/.pnpm/vue-loader@15.9.8_@vue+compiler-sfc@3.5.27_css-loader@7.1.3_@rspack+core@1.7.5_webpack@_6750296422794e158e799e5551b6f194/node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/.pnpm/vue-loader@15.9.8_@vue+compiler-sfc@3.5.27_css-loader@7.1.3_@rspack+core@1.7.5_webpack@_6750296422794e158e799e5551b6f194/node_modules/vue-loader/lib/index.js??vue-loader-options!./src/components/VabPageHeader/index.vue?vue&type=template&id=2b14fb2d&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',{staticClass:"page-header",class:_vm.customClass},[_c('div',{staticClass:"header-content"},[_c('div',{staticClass:"header-left"},[_c('h1',{staticClass:"page-title"},[(_vm.icon)?_c('vab-icon',{attrs:{"icon":_vm.icon}}):_vm._e(),_vm._v("\n        "+_vm._s(_vm.title)+"\n      ")],1),(_vm.description)?_c('p',{staticClass:"page-description",domProps:{"innerHTML":_vm._s(_vm.description)}}):_vm._e()]),(_vm.rightIcon || _vm.rightText)?_c('div',{staticClass:"header-right"},[_vm._t("right",function(){return [(_vm.rightIcon)?_c('vab-icon',{attrs:{"icon":_vm.rightIcon}}):_vm._e(),(_vm.rightText)?_c('span',[_vm._v(_vm._s(_vm.rightText))]):_vm._e()]})],2):_vm._e()])])}
var staticRenderFns = []


;// CONCATENATED MODULE: ./node_modules/.pnpm/babel-loader@10.0.0_@babel+core@7.29.0_webpack@5.105.0/node_modules/babel-loader/lib/index.js??clonedRuleSet-1[0].rules[0].use!./node_modules/.pnpm/vue-loader@15.9.8_@vue+compiler-sfc@3.5.27_css-loader@7.1.3_@rspack+core@1.7.5_webpack@_6750296422794e158e799e5551b6f194/node_modules/vue-loader/lib/index.js??vue-loader-options!./src/components/VabPageHeader/index.vue?vue&type=script&lang=js&
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/* export default */ var VabPageHeadervue_type_script_lang_js_ = ({
  name: 'VabPageHeader',
  props: {
    title: {
      type: String,
      required: true
    },
    description: {
      type: String,
      default: ''
    },
    icon: {
      type: Array,
      default: () => []
    },
    rightIcon: {
      type: Array,
      default: () => []
    },
    rightText: {
      type: String,
      default: ''
    },
    customClass: {
      type: String,
      default: ''
    }
  }
});
;// CONCATENATED MODULE: ./src/components/VabPageHeader/index.vue?vue&type=script&lang=js&
 /* export default */ var components_VabPageHeadervue_type_script_lang_js_ = (VabPageHeadervue_type_script_lang_js_); 
// EXTERNAL MODULE: ./node_modules/.pnpm/style-loader@4.0.0_webpack@5.105.0/node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js
var injectStylesIntoStyleTag = __webpack_require__(85968);
var injectStylesIntoStyleTag_default = /*#__PURE__*/__webpack_require__.n(injectStylesIntoStyleTag);
// EXTERNAL MODULE: ./node_modules/.pnpm/style-loader@4.0.0_webpack@5.105.0/node_modules/style-loader/dist/runtime/styleDomAPI.js
var styleDomAPI = __webpack_require__(6529);
var styleDomAPI_default = /*#__PURE__*/__webpack_require__.n(styleDomAPI);
// EXTERNAL MODULE: ./node_modules/.pnpm/style-loader@4.0.0_webpack@5.105.0/node_modules/style-loader/dist/runtime/insertBySelector.js
var insertBySelector = __webpack_require__(44507);
var insertBySelector_default = /*#__PURE__*/__webpack_require__.n(insertBySelector);
// EXTERNAL MODULE: ./node_modules/.pnpm/style-loader@4.0.0_webpack@5.105.0/node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js
var setAttributesWithoutAttributes = __webpack_require__(30672);
var setAttributesWithoutAttributes_default = /*#__PURE__*/__webpack_require__.n(setAttributesWithoutAttributes);
// EXTERNAL MODULE: ./node_modules/.pnpm/style-loader@4.0.0_webpack@5.105.0/node_modules/style-loader/dist/runtime/insertStyleElement.js
var insertStyleElement = __webpack_require__(32204);
var insertStyleElement_default = /*#__PURE__*/__webpack_require__.n(insertStyleElement);
// EXTERNAL MODULE: ./node_modules/.pnpm/style-loader@4.0.0_webpack@5.105.0/node_modules/style-loader/dist/runtime/styleTagTransform.js
var styleTagTransform = __webpack_require__(95385);
var styleTagTransform_default = /*#__PURE__*/__webpack_require__.n(styleTagTransform);
// EXTERNAL MODULE: ./node_modules/.pnpm/css-loader@7.1.3_@rspack+core@1.7.5_webpack@5.105.0/node_modules/css-loader/dist/cjs.js??clonedRuleSet-3[0].rules[0].use[1]!./node_modules/.pnpm/vue-loader@15.9.8_@vue+compiler-sfc@3.5.27_css-loader@7.1.3_@rspack+core@1.7.5_webpack@_6750296422794e158e799e5551b6f194/node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/.pnpm/sass-loader@10.5.2_sass@1.32.13_webpack@5.105.0/node_modules/sass-loader/dist/cjs.js??clonedRuleSet-3[0].rules[0].use[2]!./node_modules/.pnpm/vue-loader@15.9.8_@vue+compiler-sfc@3.5.27_css-loader@7.1.3_@rspack+core@1.7.5_webpack@_6750296422794e158e799e5551b6f194/node_modules/vue-loader/lib/index.js??vue-loader-options!./src/components/VabPageHeader/index.vue?vue&type=style&index=0&lang=scss&
var VabPageHeadervue_type_style_index_0_lang_scss_ = __webpack_require__(75430);
;// CONCATENATED MODULE: ./node_modules/.pnpm/style-loader@4.0.0_webpack@5.105.0/node_modules/style-loader/dist/cjs.js!./node_modules/.pnpm/css-loader@7.1.3_@rspack+core@1.7.5_webpack@5.105.0/node_modules/css-loader/dist/cjs.js??clonedRuleSet-3[0].rules[0].use[1]!./node_modules/.pnpm/vue-loader@15.9.8_@vue+compiler-sfc@3.5.27_css-loader@7.1.3_@rspack+core@1.7.5_webpack@_6750296422794e158e799e5551b6f194/node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/.pnpm/sass-loader@10.5.2_sass@1.32.13_webpack@5.105.0/node_modules/sass-loader/dist/cjs.js??clonedRuleSet-3[0].rules[0].use[2]!./node_modules/.pnpm/vue-loader@15.9.8_@vue+compiler-sfc@3.5.27_css-loader@7.1.3_@rspack+core@1.7.5_webpack@_6750296422794e158e799e5551b6f194/node_modules/vue-loader/lib/index.js??vue-loader-options!./src/components/VabPageHeader/index.vue?vue&type=style&index=0&lang=scss&

      
      
      
      
      
      
      
      
      

var options = {};

options.styleTagTransform = (styleTagTransform_default());
options.setAttributes = (setAttributesWithoutAttributes_default());
options.insert = insertBySelector_default().bind(null, "head");
options.domAPI = (styleDomAPI_default());
options.insertStyleElement = (insertStyleElement_default());

var update = injectStylesIntoStyleTag_default()(VabPageHeadervue_type_style_index_0_lang_scss_["default"], options);




       /* export default */ var components_VabPageHeadervue_type_style_index_0_lang_scss_ = (VabPageHeadervue_type_style_index_0_lang_scss_["default"] && VabPageHeadervue_type_style_index_0_lang_scss_["default"].locals ? VabPageHeadervue_type_style_index_0_lang_scss_["default"].locals : undefined);

;// CONCATENATED MODULE: ./src/components/VabPageHeader/index.vue?vue&type=style&index=0&lang=scss&

// EXTERNAL MODULE: ./node_modules/.pnpm/vue-loader@15.9.8_@vue+compiler-sfc@3.5.27_css-loader@7.1.3_@rspack+core@1.7.5_webpack@_6750296422794e158e799e5551b6f194/node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__(73329);
;// CONCATENATED MODULE: ./src/components/VabPageHeader/index.vue



;


/* normalize component */

var component = (0,componentNormalizer["default"])(
  components_VabPageHeadervue_type_script_lang_js_,
  render,
  staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* export default */ var VabPageHeader = (component.exports);

}),
77688: (function (__unused_rspack_module, __webpack_exports__, __webpack_require__) {
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": function() { return /* binding */ tab; }
});

;// CONCATENATED MODULE: ./node_modules/.pnpm/vue-loader@15.9.8_@vue+compiler-sfc@3.5.27_css-loader@7.1.3_@rspack+core@1.7.5_webpack@_6750296422794e158e799e5551b6f194/node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/.pnpm/vue-loader@15.9.8_@vue+compiler-sfc@3.5.27_css-loader@7.1.3_@rspack+core@1.7.5_webpack@_6750296422794e158e799e5551b6f194/node_modules/vue-loader/lib/index.js??vue-loader-options!./src/views/vab/tab/index.vue?vue&type=template&id=01f7f660&scoped=true&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',{staticClass:"tab-container"},[_c('vab-page-header',{attrs:{"description":"选项卡组件示例","icon":['fas', 'folder-open'],"title":"选项卡"}}),_c('el-card',{attrs:{"shadow":"never"}},[_c('div',{staticClass:"tab-content"},[_c('div',{staticClass:"tab-demo"},[_c('h3',[_vm._v("基础选项卡")]),_c('el-tabs',{model:{value:(_vm.activeTab1),callback:function ($$v) {_vm.activeTab1=$$v},expression:"activeTab1"}},[_c('el-tab-pane',{attrs:{"label":"用户管理","name":"first"}},[_c('div',{staticClass:"tab-pane-content"},[_c('el-table',{staticStyle:{"width":"100%"},attrs:{"data":_vm.tableData}},[_c('el-table-column',{attrs:{"prop":"date","label":"日期","width":"180"}}),_c('el-table-column',{attrs:{"prop":"name","label":"姓名","width":"180"}}),_c('el-table-column',{attrs:{"prop":"address","label":"地址"}})],1)],1)]),_c('el-tab-pane',{attrs:{"label":"配置管理","name":"second"}},[_c('div',{staticClass:"tab-pane-content"},[_c('el-form',{attrs:{"model":_vm.form,"label-width":"100px"}},[_c('el-form-item',{attrs:{"label":"活动名称"}},[_c('el-input',{model:{value:(_vm.form.name),callback:function ($$v) {_vm.$set(_vm.form, "name", $$v)},expression:"form.name"}})],1),_c('el-form-item',{attrs:{"label":"活动区域"}},[_c('el-select',{attrs:{"placeholder":"请选择活动区域"},model:{value:(_vm.form.region),callback:function ($$v) {_vm.$set(_vm.form, "region", $$v)},expression:"form.region"}},[_c('el-option',{attrs:{"label":"区域一","value":"shanghai"}}),_c('el-option',{attrs:{"label":"区域二","value":"beijing"}})],1)],1),_c('el-form-item',{attrs:{"label":"活动时间"}},[_c('el-col',{attrs:{"span":11}},[_c('el-date-picker',{staticStyle:{"width":"100%"},attrs:{"type":"date","placeholder":"选择日期"},model:{value:(_vm.form.date1),callback:function ($$v) {_vm.$set(_vm.form, "date1", $$v)},expression:"form.date1"}})],1),_c('el-col',{staticClass:"line",attrs:{"span":2}},[_vm._v("-")]),_c('el-col',{attrs:{"span":11}},[_c('el-time-picker',{staticStyle:{"width":"100%"},attrs:{"placeholder":"选择时间"},model:{value:(_vm.form.date2),callback:function ($$v) {_vm.$set(_vm.form, "date2", $$v)},expression:"form.date2"}})],1)],1),_c('el-form-item',{attrs:{"label":"即时配送"}},[_c('el-switch',{model:{value:(_vm.form.delivery),callback:function ($$v) {_vm.$set(_vm.form, "delivery", $$v)},expression:"form.delivery"}})],1),_c('el-form-item',{attrs:{"label":"活动性质"}},[_c('el-checkbox-group',{model:{value:(_vm.form.type),callback:function ($$v) {_vm.$set(_vm.form, "type", $$v)},expression:"form.type"}},[_c('el-checkbox',{attrs:{"label":"美食/餐厅线上活动","name":"type"}}),_c('el-checkbox',{attrs:{"label":"地推活动","name":"type"}}),_c('el-checkbox',{attrs:{"label":"线下主题活动","name":"type"}}),_c('el-checkbox',{attrs:{"label":"单纯品牌曝光","name":"type"}})],1)],1),_c('el-form-item',{attrs:{"label":"特殊资源"}},[_c('el-radio-group',{model:{value:(_vm.form.resource),callback:function ($$v) {_vm.$set(_vm.form, "resource", $$v)},expression:"form.resource"}},[_c('el-radio',{attrs:{"label":"线上品牌商赞助"}}),_c('el-radio',{attrs:{"label":"线下场地免费"}})],1)],1),_c('el-form-item',{attrs:{"label":"活动形式"}},[_c('el-input',{attrs:{"type":"textarea"},model:{value:(_vm.form.desc),callback:function ($$v) {_vm.$set(_vm.form, "desc", $$v)},expression:"form.desc"}})],1),_c('el-form-item',[_c('el-button',{attrs:{"type":"primary"},on:{"click":_vm.onSubmit}},[_vm._v("立即创建")]),_c('el-button',[_vm._v("取消")])],1)],1)],1)]),_c('el-tab-pane',{attrs:{"label":"角色管理","name":"third"}},[_c('div',{staticClass:"tab-pane-content"},[_c('el-alert',{attrs:{"title":"角色管理信息","type":"success","show-icon":""}}),_c('p',[_vm._v("当前系统角色数量: "+_vm._s(_vm.roles.length))]),_c('el-table',{staticStyle:{"width":"100%"},attrs:{"data":_vm.roles}},[_c('el-table-column',{attrs:{"prop":"id","label":"ID","width":"180"}}),_c('el-table-column',{attrs:{"prop":"name","label":"角色名称","width":"180"}}),_c('el-table-column',{attrs:{"prop":"description","label":"描述"}}),_c('el-table-column',{attrs:{"label":"操作"}},[[_c('el-button',{attrs:{"size":"mini"}},[_vm._v("编辑")]),_c('el-button',{attrs:{"size":"mini","type":"danger"}},[_vm._v("删除")])]],2)],1)],1)])],1)],1),_c('div',{staticClass:"tab-demo"},[_c('h3',[_vm._v("卡片化选项卡")]),_c('el-tabs',{attrs:{"type":"border-card"},model:{value:(_vm.activeTab2),callback:function ($$v) {_vm.activeTab2=$$v},expression:"activeTab2"}},[_c('el-tab-pane',{attrs:{"label":"首页"}},[_c('div',{staticClass:"tab-pane-content"},[_c('el-row',{attrs:{"gutter":20}},[_c('el-col',{attrs:{"span":6}},[_c('el-card',{staticClass:"box-card"},[_c('div',{staticClass:"clearfix",attrs:{"slot":"header"},slot:"header"},[_c('span',[_vm._v("用户数")])]),_c('div',{staticClass:"card-content"},[_c('p',{staticClass:"card-number"},[_vm._v("1,234")]),_c('p',{staticClass:"card-description"},[_vm._v("总用户数量")])])])],1),_c('el-col',{attrs:{"span":6}},[_c('el-card',{staticClass:"box-card"},[_c('div',{staticClass:"clearfix",attrs:{"slot":"header"},slot:"header"},[_c('span',[_vm._v("订单数")])]),_c('div',{staticClass:"card-content"},[_c('p',{staticClass:"card-number"},[_vm._v("567")]),_c('p',{staticClass:"card-description"},[_vm._v("总订单数量")])])])],1),_c('el-col',{attrs:{"span":6}},[_c('el-card',{staticClass:"box-card"},[_c('div',{staticClass:"clearfix",attrs:{"slot":"header"},slot:"header"},[_c('span',[_vm._v("销售额")])]),_c('div',{staticClass:"card-content"},[_c('p',{staticClass:"card-number"},[_vm._v("¥89,000")]),_c('p',{staticClass:"card-description"},[_vm._v("总销售额")])])])],1),_c('el-col',{attrs:{"span":6}},[_c('el-card',{staticClass:"box-card"},[_c('div',{staticClass:"clearfix",attrs:{"slot":"header"},slot:"header"},[_c('span',[_vm._v("访问量")])]),_c('div',{staticClass:"card-content"},[_c('p',{staticClass:"card-number"},[_vm._v("45,678")]),_c('p',{staticClass:"card-description"},[_vm._v("总访问量")])])])],1)],1)],1)]),_c('el-tab-pane',{attrs:{"label":"消息中心"}},[_c('div',{staticClass:"tab-pane-content"},[_c('el-timeline',_vm._l((_vm.activities),function(activity,index){return _c('el-timeline-item',{key:index,attrs:{"timestamp":activity.timestamp}},[_vm._v("\n                  "+_vm._s(activity.content)+"\n                ")])}),1)],1)]),_c('el-tab-pane',{attrs:{"label":"设置"}},[_c('div',{staticClass:"tab-pane-content"},[_c('el-form',{attrs:{"model":_vm.settingForm,"label-width":"120px"}},[_c('el-form-item',{attrs:{"label":"网站名称"}},[_c('el-input',{model:{value:(_vm.settingForm.name),callback:function ($$v) {_vm.$set(_vm.settingForm, "name", $$v)},expression:"settingForm.name"}})],1),_c('el-form-item',{attrs:{"label":"网站描述"}},[_c('el-input',{attrs:{"type":"textarea"},model:{value:(_vm.settingForm.description),callback:function ($$v) {_vm.$set(_vm.settingForm, "description", $$v)},expression:"settingForm.description"}})],1),_c('el-form-item',{attrs:{"label":"开启评论"}},[_c('el-switch',{model:{value:(_vm.settingForm.comment),callback:function ($$v) {_vm.$set(_vm.settingForm, "comment", $$v)},expression:"settingForm.comment"}})],1),_c('el-form-item',{attrs:{"label":"维护模式"}},[_c('el-switch',{model:{value:(_vm.settingForm.maintenance),callback:function ($$v) {_vm.$set(_vm.settingForm, "maintenance", $$v)},expression:"settingForm.maintenance"}})],1),_c('el-form-item',[_c('el-button',{attrs:{"type":"primary"},on:{"click":_vm.saveSettings}},[_vm._v("保存设置")])],1)],1)],1)])],1)],1)])])],1)}
var staticRenderFns = []


// EXTERNAL MODULE: ./src/components/VabPageHeader/index.vue + 5 modules
var VabPageHeader = __webpack_require__(34685);
;// CONCATENATED MODULE: ./node_modules/.pnpm/babel-loader@10.0.0_@babel+core@7.29.0_webpack@5.105.0/node_modules/babel-loader/lib/index.js??clonedRuleSet-1[0].rules[0].use!./node_modules/.pnpm/vue-loader@15.9.8_@vue+compiler-sfc@3.5.27_css-loader@7.1.3_@rspack+core@1.7.5_webpack@_6750296422794e158e799e5551b6f194/node_modules/vue-loader/lib/index.js??vue-loader-options!./src/views/vab/tab/index.vue?vue&type=script&lang=js&
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//


/* export default */ var tabvue_type_script_lang_js_ = ({
  name: 'Tab',
  components: {
    VabPageHeader: VabPageHeader["default"]
  },
  data() {
    return {
      activeTab1: 'first',
      activeTab2: 'first',
      tableData: [{
        date: '2023-05-01',
        name: '王小虎',
        address: '上海市普陀区金沙江路 1518 弄'
      }, {
        date: '2023-05-02',
        name: '王小虎',
        address: '上海市普陀区金沙江路 1517 弄'
      }, {
        date: '2023-05-03',
        name: '王小虎',
        address: '上海市普陀区金沙江路 1519 弄'
      }, {
        date: '2023-05-04',
        name: '王小虎',
        address: '上海市普陀区金沙江路 1516 弄'
      }],
      form: {
        name: '',
        region: '',
        date1: '',
        date2: '',
        delivery: false,
        type: [],
        resource: '',
        desc: ''
      },
      roles: [{
        id: 1,
        name: '管理员',
        description: '拥有系统全部权限'
      }, {
        id: 2,
        name: '编辑者',
        description: '可以编辑内容'
      }, {
        id: 3,
        name: '查看者',
        description: '只能查看内容'
      }],
      activities: [{
        content: '创建了新的项目',
        timestamp: '2023-05-01'
      }, {
        content: '完成了用户管理模块',
        timestamp: '2023-05-02'
      }, {
        content: '修复了若干bug',
        timestamp: '2023-05-03'
      }, {
        content: '发布了新版本',
        timestamp: '2023-05-04'
      }],
      settingForm: {
        name: 'Vue Admin Better',
        description: '一个优秀的后台管理系统',
        comment: true,
        maintenance: false
      }
    };
  },
  methods: {
    onSubmit() {
      this.$message('提交成功！');
    },
    saveSettings() {
      this.$message('设置已保存！');
    }
  }
});
;// CONCATENATED MODULE: ./src/views/vab/tab/index.vue?vue&type=script&lang=js&
 /* export default */ var vab_tabvue_type_script_lang_js_ = (tabvue_type_script_lang_js_); 
// EXTERNAL MODULE: ./node_modules/.pnpm/style-loader@4.0.0_webpack@5.105.0/node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js
var injectStylesIntoStyleTag = __webpack_require__(85968);
var injectStylesIntoStyleTag_default = /*#__PURE__*/__webpack_require__.n(injectStylesIntoStyleTag);
// EXTERNAL MODULE: ./node_modules/.pnpm/style-loader@4.0.0_webpack@5.105.0/node_modules/style-loader/dist/runtime/styleDomAPI.js
var styleDomAPI = __webpack_require__(6529);
var styleDomAPI_default = /*#__PURE__*/__webpack_require__.n(styleDomAPI);
// EXTERNAL MODULE: ./node_modules/.pnpm/style-loader@4.0.0_webpack@5.105.0/node_modules/style-loader/dist/runtime/insertBySelector.js
var insertBySelector = __webpack_require__(44507);
var insertBySelector_default = /*#__PURE__*/__webpack_require__.n(insertBySelector);
// EXTERNAL MODULE: ./node_modules/.pnpm/style-loader@4.0.0_webpack@5.105.0/node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js
var setAttributesWithoutAttributes = __webpack_require__(30672);
var setAttributesWithoutAttributes_default = /*#__PURE__*/__webpack_require__.n(setAttributesWithoutAttributes);
// EXTERNAL MODULE: ./node_modules/.pnpm/style-loader@4.0.0_webpack@5.105.0/node_modules/style-loader/dist/runtime/insertStyleElement.js
var insertStyleElement = __webpack_require__(32204);
var insertStyleElement_default = /*#__PURE__*/__webpack_require__.n(insertStyleElement);
// EXTERNAL MODULE: ./node_modules/.pnpm/style-loader@4.0.0_webpack@5.105.0/node_modules/style-loader/dist/runtime/styleTagTransform.js
var styleTagTransform = __webpack_require__(95385);
var styleTagTransform_default = /*#__PURE__*/__webpack_require__.n(styleTagTransform);
// EXTERNAL MODULE: ./node_modules/.pnpm/css-loader@7.1.3_@rspack+core@1.7.5_webpack@5.105.0/node_modules/css-loader/dist/cjs.js??clonedRuleSet-3[0].rules[0].use[1]!./node_modules/.pnpm/vue-loader@15.9.8_@vue+compiler-sfc@3.5.27_css-loader@7.1.3_@rspack+core@1.7.5_webpack@_6750296422794e158e799e5551b6f194/node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/.pnpm/sass-loader@10.5.2_sass@1.32.13_webpack@5.105.0/node_modules/sass-loader/dist/cjs.js??clonedRuleSet-3[0].rules[0].use[2]!./node_modules/.pnpm/vue-loader@15.9.8_@vue+compiler-sfc@3.5.27_css-loader@7.1.3_@rspack+core@1.7.5_webpack@_6750296422794e158e799e5551b6f194/node_modules/vue-loader/lib/index.js??vue-loader-options!./src/views/vab/tab/index.vue?vue&type=style&index=0&id=01f7f660&lang=scss&scoped=true&
var tabvue_type_style_index_0_id_01f7f660_lang_scss_scoped_true_ = __webpack_require__(4163);
;// CONCATENATED MODULE: ./node_modules/.pnpm/style-loader@4.0.0_webpack@5.105.0/node_modules/style-loader/dist/cjs.js!./node_modules/.pnpm/css-loader@7.1.3_@rspack+core@1.7.5_webpack@5.105.0/node_modules/css-loader/dist/cjs.js??clonedRuleSet-3[0].rules[0].use[1]!./node_modules/.pnpm/vue-loader@15.9.8_@vue+compiler-sfc@3.5.27_css-loader@7.1.3_@rspack+core@1.7.5_webpack@_6750296422794e158e799e5551b6f194/node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/.pnpm/sass-loader@10.5.2_sass@1.32.13_webpack@5.105.0/node_modules/sass-loader/dist/cjs.js??clonedRuleSet-3[0].rules[0].use[2]!./node_modules/.pnpm/vue-loader@15.9.8_@vue+compiler-sfc@3.5.27_css-loader@7.1.3_@rspack+core@1.7.5_webpack@_6750296422794e158e799e5551b6f194/node_modules/vue-loader/lib/index.js??vue-loader-options!./src/views/vab/tab/index.vue?vue&type=style&index=0&id=01f7f660&lang=scss&scoped=true&

      
      
      
      
      
      
      
      
      

var options = {};

options.styleTagTransform = (styleTagTransform_default());
options.setAttributes = (setAttributesWithoutAttributes_default());
options.insert = insertBySelector_default().bind(null, "head");
options.domAPI = (styleDomAPI_default());
options.insertStyleElement = (insertStyleElement_default());

var update = injectStylesIntoStyleTag_default()(tabvue_type_style_index_0_id_01f7f660_lang_scss_scoped_true_["default"], options);




       /* export default */ var vab_tabvue_type_style_index_0_id_01f7f660_lang_scss_scoped_true_ = (tabvue_type_style_index_0_id_01f7f660_lang_scss_scoped_true_["default"] && tabvue_type_style_index_0_id_01f7f660_lang_scss_scoped_true_["default"].locals ? tabvue_type_style_index_0_id_01f7f660_lang_scss_scoped_true_["default"].locals : undefined);

;// CONCATENATED MODULE: ./src/views/vab/tab/index.vue?vue&type=style&index=0&id=01f7f660&lang=scss&scoped=true&

// EXTERNAL MODULE: ./node_modules/.pnpm/vue-loader@15.9.8_@vue+compiler-sfc@3.5.27_css-loader@7.1.3_@rspack+core@1.7.5_webpack@_6750296422794e158e799e5551b6f194/node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__(73329);
;// CONCATENATED MODULE: ./src/views/vab/tab/index.vue



;


/* normalize component */

var component = (0,componentNormalizer["default"])(
  vab_tabvue_type_script_lang_js_,
  render,
  staticRenderFns,
  false,
  null,
  "01f7f660",
  null
  
)

/* export default */ var tab = (component.exports);

}),

}]);