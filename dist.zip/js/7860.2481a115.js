/*!
 * vue-admin-better
 * GitHub: https://github.com/zxwk1998/vue-admin-better
 * Gitee: https://gitee.com/chu1204505056/vue-admin-better
 *
 * 版权所有 (c) 2025 vue-admin-better
 * 本项目使用 MIT 许可证
 * 构建时间: 2026-2-26 02:44:42
 */
"use strict";
(self["webpackChunkvue_admin_better"] = self["webpackChunkvue_admin_better"] || []).push([["7860"], {
29791: (function (__unused_rspack_module, __webpack_exports__, __webpack_require__) {
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": function() { return /* binding */ test; }
});

;// CONCATENATED MODULE: ./node_modules/.pnpm/vue-loader@15.9.8_@vue+compiler-sfc@3.5.29_css-loader@7.1.4_@rspack+core@1.7.6_webpack@_a597eaf0f5c0d79fb3a959f14cc0bcf6/node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/.pnpm/vue-loader@15.9.8_@vue+compiler-sfc@3.5.29_css-loader@7.1.4_@rspack+core@1.7.6_webpack@_a597eaf0f5c0d79fb3a959f14cc0bcf6/node_modules/vue-loader/lib/index.js??vue-loader-options!./src/views/test/index.vue?vue&type=template&id=6e6c385e&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',{staticClass:"test-container"},[_c('el-divider',{attrs:{"content-position":"left"}},[_vm._v("你可以在这里写demo")])],1)}
var staticRenderFns = []


;// CONCATENATED MODULE: ./node_modules/.pnpm/babel-loader@10.0.0_@babel+core@7.29.0_webpack@5.105.2/node_modules/babel-loader/lib/index.js??clonedRuleSet-1[0].rules[0].use!./node_modules/.pnpm/vue-loader@15.9.8_@vue+compiler-sfc@3.5.29_css-loader@7.1.4_@rspack+core@1.7.6_webpack@_a597eaf0f5c0d79fb3a959f14cc0bcf6/node_modules/vue-loader/lib/index.js??vue-loader-options!./src/views/test/index.vue?vue&type=script&lang=js&
//
//
//
//
//

/* export default */ var testvue_type_script_lang_js_ = ({
  name: 'Test',
  data() {
    return {
      show: true
    };
  },
  created() {},
  mounted() {},
  methods: {}
});
;// CONCATENATED MODULE: ./src/views/test/index.vue?vue&type=script&lang=js&
 /* export default */ var views_testvue_type_script_lang_js_ = (testvue_type_script_lang_js_); 
// EXTERNAL MODULE: ./node_modules/.pnpm/vue-loader@15.9.8_@vue+compiler-sfc@3.5.29_css-loader@7.1.4_@rspack+core@1.7.6_webpack@_a597eaf0f5c0d79fb3a959f14cc0bcf6/node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__(75201);
;// CONCATENATED MODULE: ./src/views/test/index.vue





/* normalize component */
;
var component = (0,componentNormalizer["default"])(
  views_testvue_type_script_lang_js_,
  render,
  staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* export default */ var test = (component.exports);

}),

}]);