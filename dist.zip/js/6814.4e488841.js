(self["webpackChunkvue_admin_better"] = self["webpackChunkvue_admin_better"] || []).push([["6814"], {
61698: (function (module, __unused_webpack_exports, __webpack_require__) {
/**
 * @description 3个子配置，通用配置|主题配置|网络配置
 */
//默认配置
const {
  setting,
  theme,
  network
} = __webpack_require__(84465);
module.exports = Object.assign({}, setting, theme, network);

}),

}]);